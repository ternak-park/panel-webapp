// import './bootstrap';
import Swal from 'sweetalert2';
window.Swal = Swal;

console.log('Swal:', Swal);
import './datatable/supplier';
import './datatable/users';
import './datatable/admin';
import './datatable/reproduksi';
import './datatable/status';
import './datatable/fisik';
import './datatable/kesehatan';
import './datatable/hewan';
import './datatable/kondisi';
import './datatable/kandang';
import './datatable/hewanDetail';
import './datatable/tipe';
import './datatable/program';


import './kode';

import './kode/status';
import './tom-select.base.min';
