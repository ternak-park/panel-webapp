<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TernakKondisi extends Model
{
    use HasFactory;

    protected $table = 'ternak_kondisi';

    protected $fillable = [
        'tgl_kejadian_kondisi',
        'ternak_tag_id',
        'ternak_kandang_id',
        'ternak_jenis_id',
        'sex_hewan_kondisi',
        'ternak_kesehatan_id'
    ];

    public function ternakHewan()
    {
        return $this->belongsTo(TernakHewan::class, 'ternak_tag_id');
    }

    public function ternakKandang()
    {
        return $this->belongsTo(TernakKandang::class, 'ternak_kandang_id');
    }

    public function jenis()
    {
        return $this->belongsTo(Jenis::class, 'ternak_jenis_id');
    }

    public function kesehatan()
    {
        return $this->belongsTo(Kesehatan::class, 'ternak_kesehatan_id');
    }

    public function detailTernakKondisi()
    {
        return $this->hasMany(DetailTernakKondisi::class, 'ternak_kondisi_id');
    }
}
