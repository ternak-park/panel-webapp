<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TernakFisik extends Model
{
    use HasFactory;

    protected $table = 'ternak_fisik';

    protected $fillable = [
        'ternak_tag_id',
        'ternak_kandang_id',
        'tgl_masuk_lahir_fisik',
        'berat_masuk_fisik',
        'tgl_timbang_terakhir_fisik',
        'berat_terakhir_fisik',
        'kenaikan_berat_fisik'
    ];

    public function ternakHewan()
    {
        return $this->belongsTo(TernakHewan::class, 'ternak_tag_id');
    }

    public function ternakKandang()
    {
        return $this->belongsTo(TernakKandang::class, 'ternak_kandang_id');
    }

    public function detailTernakHewans()
    {
        return $this->hasMany(DetailTernakHewan::class, 'ternak_fisik');
    }

    public function detailTernakFisik()
    {
        return $this->hasMany(DetailTernakFisik::class, 'ternak_fisik_id');
    }
}
